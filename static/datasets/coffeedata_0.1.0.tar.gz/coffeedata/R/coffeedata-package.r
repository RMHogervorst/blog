#' coffeedata.
#'
#' Every time coffee was consumed by Roel, a time stamp was added.
#' The data contains individual observations, every row is a seperate observation.
#'
#' @name coffeedata
#' @docType package
NULL
